# t5_multimodal_fusion_eval_win.py
# Clean, Windows/CPU-friendly version of your friend's script.
# - Works with single CSV (auto stratified split) or 3 CSV splits.
# - Robust labels: pads -> -100
# - Trainer args compatible across transformers versions
# - Keeps teacher-forced scoring to get class probs (no predict_with_generate)

import os, re, math, random, argparse, tempfile, json
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch

from datasets import Dataset
from sklearn.metrics import (
    accuracy_score, precision_recall_fscore_support,
    confusion_matrix, ConfusionMatrixDisplay,
    roc_curve, auc, precision_recall_curve, average_precision_score
)
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

import matplotlib
matplotlib.use('Agg')  # headless
import matplotlib.pyplot as plt

from transformers import (
    T5ForConditionalGeneration,
    T5TokenizerFast,
    DataCollatorForSeq2Seq,
    Trainer,
    TrainingArguments,
)

# ---------- Defaults you can change ----------
MODEL_NAME = "t5-small"
SEED = 42
MAX_SOURCE_LEN = 512
MAX_TARGET_LEN = 8
LABEL_COL = "label"
TEXT_COLS = ["video_title", "video_description", "audio_transcript"]
ALLOWED_LABELS = ["misinformation", "reliable"]
ID_COL_DEFAULT = "video_id"

# Optional metadata columns (if present, they’ll be used)
NUM_META_CANDS = ["video_view_count", "video_like_count", "video_comment_count", "video_view_count_log"]

# -------------- Utils -----------------
def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def get_writable_dir(preferred: Optional[str] = None) -> str:
    cands = []
    if preferred: cands.append(preferred)
    cands.append(os.path.join(os.getcwd(), "t5_mhmisinfo_mm"))
    cands.append(os.path.join(os.path.expanduser("~"), "t5_runs", "t5_mhmisinfo_mm"))
    for c in cands:
        try:
            os.makedirs(c, exist_ok=True)
            tf = os.path.join(c, ".writetest")
            with open(tf, "w") as f: f.write("ok")
            os.remove(tf)
            return c
        except Exception:
            continue
    return tempfile.mkdtemp(prefix="t5_mhmisinfo_mm_")

def safe_text(x):
    if pd.isna(x): return ""
    return str(x)

def build_text(row: pd.Series) -> str:
    title = safe_text(row.get("video_title", ""))
    desc  = safe_text(row.get("video_description", ""))
    trans = safe_text(row.get("audio_transcript", ""))
    # prompt shaped for T5 classification
    return (
        "classify mental health misinformation.\n\n"
        f"[TITLE] {title}\n[DESC] {desc}\n[TRANSCRIPT] {trans}\n"
        "Answer with either: misinformation or reliable."
    )

def clean_label(y: str) -> str:
    y = str(y).strip().lower()
    if y not in ALLOWED_LABELS:
        y = "reliable"
    return y

def load_csv_basic(path: str, id_col: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    keep = [c for c in df.columns if c in TEXT_COLS + [LABEL_COL, id_col] + NUM_META_CANDS]
    df = df[keep].copy()
    df["text"] = df.apply(build_text, axis=1)
    df[LABEL_COL] = df[LABEL_COL].apply(clean_label)
    df = df[df["text"].str.strip().str.len() > 0].reset_index(drop=True)
    return df

def split_from_single_csv(csv_path: str, id_col: str):
    df = load_csv_basic(csv_path, id_col)
    # stratified 80/10/10
    tr, tmp = train_test_split(df, test_size=0.2, stratify=df[LABEL_COL], random_state=SEED)
    val, te = train_test_split(tmp, test_size=0.5, stratify=tmp[LABEL_COL], random_state=SEED)
    return tr.reset_index(drop=True), val.reset_index(drop=True), te.reset_index(drop=True)

def to_hf_dataset(df: pd.DataFrame) -> Dataset:
    return Dataset.from_pandas(df[["text", LABEL_COL]], preserve_index=False)

def prepare_tokenizer_and_model(model_name: str):
    tokenizer = T5TokenizerFast.from_pretrained(model_name)
    model     = T5ForConditionalGeneration.from_pretrained(model_name)
    return tokenizer, model

def tokenize_batch(examples, tokenizer):
    # inputs
    mi = tokenizer(
        examples["text"],
        max_length=MAX_SOURCE_LEN,
        truncation=True,
        padding="max_length",
    )
    # targets
    try:
        # newer transformers
        labels = tokenizer(
            text_target=examples[LABEL_COL],
            max_length=MAX_TARGET_LEN,
            truncation=True,
            padding="max_length",
        )["input_ids"]
    except TypeError:
        # fallback for older versions
        with tokenizer.as_target_tokenizer():
            labels = tokenizer(
                examples[LABEL_COL],
                max_length=MAX_TARGET_LEN,
                truncation=True,
                padding="max_length",
            )["input_ids"]

    # mask pads in labels with -100 so loss ignores them
    pad_id = tokenizer.pad_token_id
    labels = [[(tok if tok != pad_id else -100) for tok in seq] for seq in labels]
    mi["labels"] = labels
    return mi

# ----- T5: teacher-forced probability for each class -----
@torch.no_grad()
def _seq_negloglik(tokenizer, model, prompt_ids, prompt_mask, target_text: str) -> float:
    try:
        lab = tokenizer(text_target=[target_text], max_length=MAX_TARGET_LEN, truncation=True,
                        padding="max_length", return_tensors="pt")
    except TypeError:
        with tokenizer.as_target_tokenizer():
            lab = tokenizer([target_text], max_length=MAX_TARGET_LEN, truncation=True,
                            padding="max_length", return_tensors="pt")
    labels = lab["input_ids"].to(model.device)
    labels[labels == tokenizer.pad_token_id] = -100
    out = model(input_ids=prompt_ids, attention_mask=prompt_mask, labels=labels)
    tgt_len = int((labels != -100).sum().item())
    return float(out.loss.item()) * max(tgt_len, 1)

def t5_prob_misinfo(texts: List[str], tokenizer, model) -> np.ndarray:
    device = model.device
    model.eval()
    probs = []
    import math as _math
    for t in texts:
        enc = tokenizer(t, return_tensors="pt", truncation=True, max_length=MAX_SOURCE_LEN).to(device)
        logps = []
        for lab in ALLOWED_LABELS:
            nll = _seq_negloglik(tokenizer, model, enc["input_ids"], enc["attention_mask"], lab)
            # score = -NLL (higher is better)
            logps.append(-nll)
        m = max(logps)
        exps = [_math.exp(z - m) for z in logps]
        s = sum(exps)
        p_mis = exps[ALLOWED_LABELS.index("misinformation")] / s
        probs.append(p_mis)
    return np.array(probs, dtype=np.float32)

# ---- Optional vision + metadata late fusion bits (safe if absent) ----
def load_vision_npz(npz_path: str) -> Dict[str, np.ndarray]:
    data = np.load(npz_path, allow_pickle=True)
    if "ids" in data and "embs" in data:
        ids, embs = data["ids"], data["embs"]
        return {str(ids[i]): embs[i] for i in range(len(ids))}
    out = {}
    for k in data.files: out[k] = data[k]
    return out

def attach_vision_features(df: pd.DataFrame, id_col: str, cache: Dict[str, np.ndarray]) -> Optional[np.ndarray]:
    vecs, missing = [], 0
    for vid in df.get(id_col, pd.Series([""]*len(df))).astype(str).tolist():
        v = cache.get(vid)
        if v is None: vecs.append(None); missing += 1
        else: vecs.append(v)
    if missing == len(vecs): return None
    arr = np.array([x for x in vecs if x is not None], dtype=np.float32)
    mu = arr.mean(axis=0)
    final = np.stack([mu if x is None else x for x in vecs], axis=0)
    return final.astype(np.float32)

def extract_metadata(df: pd.DataFrame) -> Optional[np.ndarray]:
    cols = [c for c in NUM_META_CANDS if c in df.columns]
    if not cols: return None
    return df[cols].fillna(0).astype(float).values

def fit_sklearn_head(X_train, y_train):
    pipe = Pipeline([
        ("scaler", StandardScaler(with_mean=True, with_std=True)),
        ("clf", LogisticRegression(max_iter=1000, class_weight="balanced"))
    ])
    pipe.fit(X_train, y_train)
    return pipe

def prob_mis_from_head(pipe, X) -> np.ndarray:
    if hasattr(pipe, "predict_proba"):
        proba = pipe.predict_proba(X)
        idx = list(pipe.classes_).index("misinformation")
        return proba[:, idx].astype(np.float32)
    d = pipe.decision_function(X)
    from scipy.special import expit
    return expit(d).astype(np.float32)

# -------- Metrics & plots ----------
def metrics_from_probs(y_true: List[str], p_mis: np.ndarray, threshold=0.5):
    y_pred = np.where(p_mis >= threshold, "misinformation", "reliable")
    acc = accuracy_score(y_true, y_pred)
    p, r, f1, _ = precision_recall_fscore_support(y_true, y_pred, average="macro", zero_division=0)
    y_bin = np.array([1 if y=="misinformation" else 0 for y in y_true], dtype=np.int32)
    fpr, tpr, _ = roc_curve(y_bin, p_mis)
    auc_val = auc(fpr, tpr)
    prec, rec, _ = precision_recall_curve(y_bin, p_mis)
    ap = average_precision_score(y_bin, p_mis)
    return {"accuracy": acc, "precision_macro": p, "recall_macro": r, "f1_macro": f1, "roc_auc": auc_val, "avg_precision": ap}, y_pred, (fpr, tpr), (prec, rec)

def save_confusion(y_true, y_pred, labels, path_png, title):
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
    plt.figure(); disp.plot(values_format='d'); plt.title(title); plt.tight_layout(); plt.savefig(path_png, dpi=220); plt.close()

def save_curve(x, y, xlabel, ylabel, title, out_png, legend=None):
    plt.figure(); plt.plot(x, y, label=legend if legend else None)
    if legend: plt.legend(loc='lower right')
    plt.xlabel(xlabel); plt.ylabel(ylabel); plt.title(title)
    plt.tight_layout(); plt.savefig(out_png, dpi=220); plt.close()

def tune_late_fusion(val_scores: Dict[str, np.ndarray], y_val: List[str], step: float = 0.1):
    keys = list(val_scores.keys())
    if len(keys) == 0:
        return {"weights": {}, "best_f1": 0.0, "best_scores": None}
    if len(keys) == 1:
        return {"weights": {keys[0]: 1.0}, "best_f1": metrics_from_probs(y_val, val_scores[keys[0]])[0]["f1_macro"], "best_scores": val_scores[keys[0]]}
    grid = np.arange(0, 1+1e-9, step)
    best = {"weights": None, "best_f1": -1, "best_scores": None}
    if len(keys) == 2:
        for a in grid:
            w = {keys[0]: a, keys[1]: 1-a}
            fused = w[keys[0]]*val_scores[keys[0]] + w[keys[1]]*val_scores[keys[1]]
            f1 = metrics_from_probs(y_val, fused)[0]["f1_macro"]
            if f1 > best["best_f1"]:
                best = {"weights": w, "best_f1": f1, "best_scores": fused}
    else:
        for a in grid:
            for b in grid:
                c = 1 - a - b
                if c < -1e-9: continue
                w = {keys[0]: a, keys[1]: b, keys[2]: c}
                fused = sum(w[k]*val_scores[k] for k in keys)
                f1 = metrics_from_probs(y_val, fused)[0]["f1_macro"]
                if f1 > best["best_f1"]:
                    best = {"weights": w, "best_f1": f1, "best_scores": fused}
    return best

def plot_learning_curves(trainer_log_history, out_png):
    last_train, last_eval = {}, {}
    for rec in trainer_log_history:
        if "epoch" in rec and "loss" in rec: last_train[rec["epoch"]] = rec["loss"]
        if "epoch" in rec and "eval_loss" in rec: last_eval[rec["epoch"]] = rec["eval_loss"]
    ks = sorted(set(list(last_train.keys()) + list(last_eval.keys())))
    if not ks: return
    tr = [last_train.get(k, np.nan) for k in ks]
    ev = [last_eval.get(k, np.nan) for k in ks]
    plt.figure()
    plt.plot(ks, tr, marker='o', label="train_loss")
    plt.plot(ks, ev, marker='o', label="eval_loss")
    plt.xlabel("Epoch"); plt.ylabel("Loss"); plt.title("Learning Curves — T5")
    plt.legend(); plt.tight_layout(); plt.savefig(out_png, dpi=220); plt.close()

# -------------- Main -----------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=str, default=None)
    parser.add_argument("--id_col", type=str, default=ID_COL_DEFAULT)
    parser.add_argument("--csv", type=str, default=None, help="Single CSV with label & text columns (auto-split 80/10/10)")
    parser.add_argument("--train", type=str, default=None)
    parser.add_argument("--val",   type=str, default=None)
    parser.add_argument("--test",  type=str, default=None)
    parser.add_argument("--vision_npz", type=str, default=None, help="Optional OpenCLIP npz cache (ids, embs)")
    args, _ = parser.parse_known_args()

    outdir = get_writable_dir(args.out)
    print(f"[INFO] Output directory: {outdir}")

    set_seed(SEED)

    # Load data
    if args.csv:
        print("[INFO] Using single CSV (auto-split 80/10/10):", args.csv)
        train_df, val_df, test_df = split_from_single_csv(args.csv, args.id_col)
    else:
        assert args.train and args.val and args.test, "Provide --csv OR all of --train --val --test."
        print("[INFO] Using provided splits.")
        train_df = load_csv_basic(args.train, args.id_col)
        val_df   = load_csv_basic(args.val,   args.id_col)
        test_df  = load_csv_basic(args.test,  args.id_col)

    # Tokenizer/model
    tokenizer, model = prepare_tokenizer_and_model(MODEL_NAME)

    # HF datasets
    hf_train = to_hf_dataset(train_df)
    hf_val   = to_hf_dataset(val_df)

    # Tokenize (with robust label masking)
    hf_train_tok = hf_train.map(lambda ex: tokenize_batch(ex, tokenizer), batched=True, remove_columns=hf_train.column_names)
    hf_val_tok   = hf_val.map(  lambda ex: tokenize_batch(ex, tokenizer), batched=True, remove_columns=hf_val.column_names)
    collator = DataCollatorForSeq2Seq(tokenizer=tokenizer, model=model)

    # Trainer args — keep version-agnostic & CPU-safe
    targs = TrainingArguments(
        output_dir=outdir,
        num_train_epochs=2,
        per_device_train_batch_size=4,
        per_device_eval_batch_size=4,
        gradient_accumulation_steps=2,
        learning_rate=5e-5,
        weight_decay=0.01,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        logging_steps=50,
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",
        greater_is_better=False,
        fp16=torch.cuda.is_available(),  # off on CPU
        report_to="none"  # avoids WandB/TS
    )

    trainer = Trainer(
        model=model,
        args=targs,
        train_dataset=hf_train_tok,
        eval_dataset=hf_val_tok,
        data_collator=collator,
        tokenizer=tokenizer,
    )

    print("[INFO] Training T5 (text modality)...")
    trainer.train()
    plot_learning_curves(trainer.state.log_history, os.path.join(outdir, "learning_curves_t5.png"))

    # text-only probs (teacher-forced scoring; robust on CPU & any transformers version)
    y_val_true  = val_df[LABEL_COL].tolist()
    y_test_true = test_df[LABEL_COL].tolist()
    p_text_val  = t5_prob_misinfo(val_df["text"].tolist(), tokenizer, trainer.model)
    p_text_test = t5_prob_misinfo(test_df["text"].tolist(), tokenizer, trainer.model)

    # Optional vision + metadata
    vision_cache = None
    if args.vision_npz and os.path.exists(args.vision_npz):
        print(f"[INFO] Loading vision embeddings from {args.vision_npz}")
        vision_cache = load_vision_npz(args.vision_npz)

    Xv_tr = Xv_val = Xv_te = None
    if vision_cache is not None:
        Xv_tr  = attach_vision_features(train_df, args.id_col, vision_cache)
        Xv_val = attach_vision_features(val_df,   args.id_col, vision_cache)
        Xv_te  = attach_vision_features(test_df,  args.id_col, vision_cache)

    Xm_tr  = extract_metadata(train_df)
    Xm_val = extract_metadata(val_df)
    Xm_te  = extract_metadata(test_df)

    vision_head = None; meta_head = None
    if Xv_tr is not None:
        print("[INFO] Training vision-only head (LogReg) ...")
        vision_head = fit_sklearn_head(Xv_tr, train_df[LABEL_COL])
    if Xm_tr is not None:
        print("[INFO] Training metadata-only head (LogReg) ...")
        meta_head = fit_sklearn_head(Xm_tr, train_df[LABEL_COL])

    # Collect scores
    val_scores  = {"text": p_text_val}
    test_scores = {"text": p_text_test}
    if vision_head is not None:
        val_scores["vision"] = prob_mis_from_head(vision_head, Xv_val)
        test_scores["vision"] = prob_mis_from_head(vision_head, Xv_te)
    if meta_head is not None:
        val_scores["meta"] = prob_mis_from_head(meta_head, Xm_val)
        test_scores["meta"] = prob_mis_from_head(meta_head, Xm_te)

    # Unimodal metrics
    unimodal_val_metrics = {}
    for k, p in val_scores.items():
        m, y_pred, (fpr, tpr), (prec, rec) = metrics_from_probs(y_val_true, p)
        unimodal_val_metrics[k] = m
        save_confusion(y_val_true, y_pred, ALLOWED_LABELS, os.path.join(outdir, f"cm_val_{k}.png"), f"Confusion Matrix — Validation ({k})")
        save_curve(fpr, tpr, "False Positive Rate", "True Positive Rate", f"ROC — Val ({k})", os.path.join(outdir, f"roc_val_{k}.png"), legend=f"AUC={m['roc_auc']:.3f}")
        save_curve(rec, prec, "Recall", "Precision", f"PR — Val ({k})", os.path.join(outdir, f"pr_val_{k}.png"))
    pd.DataFrame(unimodal_val_metrics).to_csv(os.path.join(outdir, "unimodal_val_metrics.csv"), index=False)

    # Late fusion (text + optional vision/meta)
    best = tune_late_fusion(val_scores, y_val_true, step=0.1)
    print("[INFO] Best fusion weights (val):", best["weights"], " Val F1:", best["best_f1"])
    with open(os.path.join(outdir, "fusion_weights.json"), "w") as f:
        json.dump({"weights": best["weights"], "val_f1": best["best_f1"]}, f)

    if best["weights"]:
        p_val_fused  = sum(best["weights"][k] * val_scores[k]  for k in best["weights"])
        p_test_fused = sum(best["weights"][k] * test_scores[k] for k in best["weights"])

        m_val, ypv, (fprv, tprv), (precv, recv) = metrics_from_probs(y_val_true, p_val_fused)
        m_te,  ypt, (fprt, tprt), (prect, rect) = metrics_from_probs(y_test_true, p_test_fused)

        pd.DataFrame([m_val]).to_csv(os.path.join(outdir, "metrics_val_fused.csv"), index=False)
        pd.DataFrame([m_te]).to_csv(os.path.join(outdir, "metrics_test_fused.csv"), index=False)

        save_confusion(y_val_true, ypv, ALLOWED_LABELS, os.path.join(outdir, "cm_val_fused.png"), "Confusion Matrix — Validation (Fused)")
        save_confusion(y_test_true, ypt, ALLOWED_LABELS, os.path.join(outdir, "cm_test_fused.png"), "Confusion Matrix — Test (Fused)")
        save_curve(fprv, tprv, "False Positive Rate", "True Positive Rate", "ROC — Val (Fused)",  os.path.join(outdir, "roc_val_fused.png"),  legend=f"AUC={m_val['roc_auc']:.3f}")
        save_curve(fprt, tprt, "False Positive Rate", "True Positive Rate", "ROC — Test (Fused)", os.path.join(outdir, "roc_test_fused.png"), legend=f"AUC={m_te['roc_auc']:.3f}")
        save_curve(recv, precv, "Recall", "Precision", "PR — Val (Fused)",  os.path.join(outdir, "pr_val_fused.png"))
        save_curve(rect, prect, "Recall", "Precision", "PR — Test (Fused)", os.path.join(outdir, "pr_test_fused.png"))
    else:
        print("[WARN] Only one modality available; fusion not applied.")

    # Compare test macro-F1 across modalities
    compare_rows = []
    mt, yt, _, _ = metrics_from_probs(y_test_true, test_scores["text"])
    compare_rows.append({"model":"text","accuracy":mt["accuracy"],"f1_macro":mt["f1_macro"],"roc_auc":mt["roc_auc"]})
    if "vision" in test_scores:
        mv, yv, _, _ = metrics_from_probs(y_test_true, test_scores["vision"])
        compare_rows.append({"model":"vision","accuracy":mv["accuracy"],"f1_macro":mv["f1_macro"],"roc_auc":mv["roc_auc"]})
    if "meta" in test_scores:
        mm, ym, _, _ = metrics_from_probs(y_test_true, test_scores["meta"])
        compare_rows.append({"model":"metadata","accuracy":mm["accuracy"],"f1_macro":mm["f1_macro"],"roc_auc":mm["roc_auc"]})
    if best["weights"]:
        mF = pd.read_csv(os.path.join(outdir, "metrics_test_fused.csv")).iloc[0].to_dict()
        compare_rows.append({"model":"fused","accuracy":float(mF["accuracy"]),"f1_macro":float(mF["f1_macro"]),"roc_auc":float(mF["roc_auc"])})
    df_compare = pd.DataFrame(compare_rows)
    df_compare.to_csv(os.path.join(outdir, "compare_test_unimodal_vs_fused.csv"), index=False)

    if not df_compare.empty:
        plt.figure()
        plt.bar(df_compare["model"], df_compare["f1_macro"])
        plt.xlabel("Model / Modality"); plt.ylabel("Macro-F1"); plt.title("Modality Contribution — Test Macro-F1")
        plt.tight_layout(); plt.savefig(os.path.join(outdir, "modality_contribution_test.png"), dpi=220)
        plt.close()

    # Simple agreement analysis
    analysis_rows = []
    text_pred = np.where(test_scores["text"] >= 0.5, "misinformation", "reliable")
    for i in range(len(y_test_true)):
        rec = {"text_correct": int(text_pred[i] == y_test_true[i])}
        if "vision" in test_scores:
            vpred = "misinformation" if test_scores["vision"][i] >= 0.5 else "reliable"
            rec["vision_correct"] = int(vpred == y_test_true[i])
        if "meta" in test_scores:
            mpred = "misinformation" if test_scores["meta"][i] >= 0.5 else "reliable"
            rec["meta_correct"] = int(mpred == y_test_true[i])
        rec["label"] = y_test_true[i]
        analysis_rows.append(rec)
    if analysis_rows:
        pd.DataFrame(analysis_rows).to_csv(os.path.join(outdir, "modality_agreement_test.csv"), index=False)

    print("[DONE] All outputs are in:", outdir)

if __name__ == "__main__":
    main()
