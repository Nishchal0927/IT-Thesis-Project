import os, math, random, json, argparse
from dataclasses import dataclass
from typing import List, Dict

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, roc_curve, auc, precision_recall_curve, average_precision_score

from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    get_linear_schedule_with_warmup,
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
import bitsandbytes as bnb
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# -------------------------
# Config (edit as needed)
# -------------------------
MODEL_NAME = "mistralai/Mistral-7B-Instruct-v0.2"
SEED = 42
MAX_SRC_TOKENS = 1024           # 7B can handle 8k; keep smaller for speed
MAX_LABEL_TOKENS = 4            # "misinformation" or "reliable"
BATCH_SIZE = 2                  # micro-batch
GRAD_ACCUM = 8                  # effective batch = 16
EPOCHS = 2
LR = 2e-4
WARMUP_RATIO = 0.05
WEIGHT_DECAY = 0.0

LORA_R = 16
LORA_ALPHA = 32
LORA_DROPOUT = 0.05
LORA_TARGET_MODULES = ["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"]  # Mistral blocks

LABELS = ["reliable","misinformation"]  # index 0, 1
PROMPT_SUFFIX = "Answer with either: misinformation or reliable."

# -------------------------
# Repro
# -------------------------
def set_seed(s=SEED):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)

# -------------------------
# Data
# -------------------------
def safe(x): 
    return "" if (x is None or (isinstance(x,float) and np.isnan(x))) else str(x)

def build_prompt(row: pd.Series) -> str:
    title = safe(row.get("video_title"))
    desc  = safe(row.get("video_description"))
    trans = safe(row.get("audio_transcript"))
    return (
        "classify mental health misinformation.\n\n"
        f"[TITLE] {title}\n[DESC] {desc}\n[TRANSCRIPT] {trans}\n"
        f"{PROMPT_SUFFIX}"
    )

def load_dataframe(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    assert "label" in df.columns, "CSV must have a 'label' column with 'misinformation' or 'reliable'."
    df["label"] = df["label"].astype(str).str.strip().str.lower()
    df = df[df["label"].isin(["misinformation","reliable"])].copy()
    df["text"] = df.apply(build_prompt, axis=1)
    df = df[df["text"].str.strip().str.len() > 0].reset_index(drop=True)
    return df

def stratified_split(df: pd.DataFrame, seed=SEED):
    # 80/10/10 split
    from sklearn.model_selection import train_test_split
    train_df, tmp = train_test_split(df, test_size=0.2, stratify=df["label"], random_state=seed)
    val_df, test_df = train_test_split(tmp, test_size=0.5, stratify=tmp["label"], random_state=seed)
    return train_df.reset_index(drop=True), val_df.reset_index(drop=True), test_df.reset_index(drop=True)

@dataclass
class Batch:
    input_ids: torch.Tensor
    attention_mask: torch.Tensor
    labels: torch.Tensor

class SupervisedCausalDataset(Dataset):
    """
    Turn each (prompt, label_word) into a single causal string:
    "<prompt>\nFinal answer: reliable"
    and mask loss on the prompt tokens so only the target answer contributes to loss.
    """
    def __init__(self, frame: pd.DataFrame, tok: AutoTokenizer):
        self.df = frame
        self.tok = tok

    def __len__(self): return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        prompt = row["text"]
        gold = row["label"]  # "misinformation" or "reliable"

        full = f"{prompt}\nFinal answer: {gold}"
        enc = self.tok(
            full, max_length=MAX_SRC_TOKENS + MAX_LABEL_TOKENS + 8,
            truncation=True, padding="max_length", return_tensors="pt"
        )
        # We want to mask the loss on the prompt part. Find where the answer begins:
        # Simple tactic: tokenize prompt alone and use its length.
        with torch.no_grad():
            p_ids = self.tok(prompt + "\nFinal answer: ", truncation=True, max_length=MAX_SRC_TOKENS+8, return_tensors="pt")
        prompt_len = p_ids["input_ids"].shape[1]

        input_ids = enc["input_ids"][0]
        attn = enc["attention_mask"][0]
        labels = input_ids.clone()
        # Mask prompt tokens as -100 so they don't count in loss
        labels[:prompt_len] = -100

        return {
            "input_ids": input_ids,
            "attention_mask": attn,
            "labels": labels
        }

def collate_fn(items: List[Dict[str, torch.Tensor]]) -> Batch:
    input_ids = torch.stack([x["input_ids"] for x in items], dim=0)
    attn      = torch.stack([x["attention_mask"] for x in items], dim=0)
    labels    = torch.stack([x["labels"] for x in items], dim=0)
    return Batch(input_ids, attn, labels)

# -------------------------
# Probabilities via teacher forcing (no generation)
# -------------------------
@torch.no_grad()
def score_label_logprob(tokenizer, model, prompt_ids, prompt_mask, target_text: str) -> float:
    """
    For one example: compute negative log-likelihood of `target_text` given the prompt.
    Convert the average loss to total NLL by multiplying by number of target tokens.
    """
    target_ids = tokenizer(
        target_text, truncation=True, max_length=MAX_LABEL_TOKENS,
        padding="max_length", return_tensors="pt"
    )["input_ids"].to(model.device)
    # Construct a combined sequence: prompt + "Final answer: " + <target>
    # Easiest: pass as labels only (teacher forcing)
    full_in = {"input_ids": prompt_ids, "attention_mask": prompt_mask, "labels": target_ids}
    out = model(**full_in)
    # loss is mean over non-pad target tokens -> total NLL = loss * target_len
    tgt_len = int((target_ids != tokenizer.pad_token_id).sum().item())
    return float(out.loss.item()) * max(tgt_len, 1)

@torch.no_grad()
def predict_proba_texts(tokenizer, model, prompts: List[str]) -> np.ndarray:
    """
    Returns P(misinformation) for each prompt using softmax over {reliable, misinformation} log-likelihoods.
    """
    ps = []
    for p in prompts:
        enc = tokenizer(p, return_tensors="pt", truncation=True, max_length=MAX_SRC_TOKENS).to(model.device)
        logps = []
        for lab in LABELS:
            nll = score_label_logprob(tokenizer, model, enc["input_ids"], enc["attention_mask"], lab)
            logps.append(-nll)
        # stable softmax
        m = max(logps); exps = [math.exp(z - m) for z in logps]; s = sum(exps)
        p_mis = exps[LABELS.index("misinformation")] / s
        ps.append(p_mis)
    return np.array(ps, dtype=np.float32)

# -------------------------
# Train / Eval
# -------------------------
def evaluate_probs(y_true: List[str], p_mis: np.ndarray, prefix: str, outdir: str):
    y_pred = np.where(p_mis >= 0.5, "misinformation", "reliable")
    acc = accuracy_score(y_true, y_pred)
    p, r, f1, _ = precision_recall_fscore_support(y_true, y_pred, average="macro", zero_division=0)

    yb = np.array([1 if y=="misinformation" else 0 for y in y_true], dtype=np.int32)
    fpr, tpr, _ = roc_curve(yb, p_mis)
    roc_auc = auc(fpr, tpr)
    prec, rec, _ = precision_recall_curve(yb, p_mis)
    ap = average_precision_score(yb, p_mis)

    # plots
    plt.figure(); plt.plot(fpr, tpr); plt.xlabel("FPR"); plt.ylabel("TPR"); plt.title(f"ROC — {prefix} (AUC={roc_auc:.3f})"); plt.tight_layout()
    plt.savefig(os.path.join(outdir, f"roc_{prefix}.png"), dpi=220); plt.close()
    plt.figure(); plt.plot(rec, prec); plt.xlabel("Recall"); plt.ylabel("Precision"); plt.title(f"PR — {prefix} (AP={ap:.3f})"); plt.tight_layout()
    plt.savefig(os.path.join(outdir, f"pr_{prefix}.png"), dpi=220); plt.close()

    metrics = {"accuracy":acc, "precision_macro":p, "recall_macro":r, "f1_macro":f1, "roc_auc":roc_auc, "avg_precision":ap}
    with open(os.path.join(outdir, f"metrics_{prefix}.json"), "w") as f:
        json.dump(metrics, f, indent=2)
    return metrics

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", type=str, required=True, help="Path to full dataset CSV (will split 80/10/10)")
    ap.add_argument("--out", type=str, default="mistral_qlora_runs")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    set_seed(SEED)

    # --- Load data
    df = load_dataframe(args.csv)
    train_df, val_df, test_df = stratified_split(df)

    # --- Tokenizer & 4-bit model
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    print("[INFO] Loading 4-bit quantized model (requires GPU / CUDA).")
    device_map = "auto" if torch.cuda.is_available() else None
    if not torch.cuda.is_available():
        print("[WARN] CUDA not available. A 7B model will likely OOM on CPU. Use a GPU runtime for training.")
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_NAME,
        load_in_4bit=True,
        torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
        device_map=device_map,
        quantization_config=bnb.nn.Linear4bitLt.make_quantization_config(dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32),
    )
    model = prepare_model_for_kbit_training(model)
    lora_cfg = LoraConfig(
        r=LORA_R, lora_alpha=LORA_ALPHA, target_modules=LORA_TARGET_MODULES, lora_dropout=LORA_DROPOUT, bias="none", task_type="CAUSAL_LM"
    )
    model = get_peft_model(model, lora_cfg)
    model.print_trainable_parameters()

    # --- Datasets & loaders
    class_map = {"misinformation":"misinformation", "reliable":"reliable"}  # just to be explicit
    tr = train_df.copy()
    va = val_df.copy()
    te = test_df.copy()

    train_ds = SupervisedCausalDataset(tr, tokenizer)
    val_ds   = SupervisedCausalDataset(va, tokenizer)
    test_ds  = SupervisedCausalDataset(te, tokenizer)

    train_dl = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True,  collate_fn=collate_fn)
    val_dl   = DataLoader(val_ds,   batch_size=BATCH_SIZE, shuffle=False, collate_fn=collate_fn)

    # --- Optim & schedule
    total_steps = max(1, (len(train_dl) // GRAD_ACCUM) * EPOCHS)
    warmup = max(1, int(WARMUP_RATIO * total_steps))
    optim = bnb.optim.AdamW8bit(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
    sched = get_linear_schedule_with_warmup(optim, num_warmup_steps=warmup, num_training_steps=total_steps)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    scaler = torch.cuda.amp.GradScaler(enabled=torch.cuda.is_available())

    # --- Train loop
    step_count = 0
    best_val_f1 = -1.0
    for epoch in range(1, EPOCHS+1):
        model.train()
        running = 0.0
        optim.zero_grad(set_to_none=True)
        for step, batch in enumerate(train_dl, 1):
            ids = batch.input_ids.to(device)
            msk = batch.attention_mask.to(device)
            lbl = batch.labels.to(device)
            with torch.cuda.amp.autocast(enabled=torch.cuda.is_available()):
                out = model(input_ids=ids, attention_mask=msk, labels=lbl)
                loss = out.loss / GRAD_ACCUM
            scaler.scale(loss).backward()
            if step % GRAD_ACCUM == 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                scaler.step(optim); scaler.update()
                sched.step()
                optim.zero_grad(set_to_none=True)
                step_count += 1
            running += loss.item()
        avg_loss = running / max(1, len(train_dl))
        print(f"Epoch {epoch}/{EPOCHS} - train_loss: {avg_loss:.4f}")

        # quick val via teacher-forced probabilities
        model.eval()
        p_val = predict_proba_texts(tokenizer, model, va["text"].tolist())
        val_metrics = evaluate_probs(va["label"].tolist(), p_val, prefix=f"val_e{epoch}", outdir=args.out)
        print("Val macro-F1:", val_metrics["f1_macro"])

        # save best adapter
        if val_metrics["f1_macro"] > best_val_f1:
            best_val_f1 = val_metrics["f1_macro"]
            save_dir = os.path.join(args.out, "best_adapter")
            os.makedirs(save_dir, exist_ok=True)
            model.save_pretrained(save_dir)
            tokenizer.save_pretrained(save_dir)
            print("[INFO] Saved best adapter to", save_dir)

    # --- Final test (load best)
    best_dir = os.path.join(args.out, "best_adapter")
    if os.path.isdir(best_dir):
        from peft import PeftModel
        base = AutoModelForCausalLM.from_pretrained(
            MODEL_NAME,
            load_in_4bit=True,
            torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
            device_map=device_map,
            quantization_config=bnb.nn.Linear4bitLt.make_quantization_config(dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32),
        )
        base = prepare_model_for_kbit_training(base)
        model = PeftModel.from_pretrained(base, best_dir).to(device)
        tokenizer = AutoTokenizer.from_pretrained(best_dir, use_fast=True)
        if tokenizer.pad_token is None: tokenizer.pad_token = tokenizer.eos_token

    p_test = predict_proba_texts(tokenizer, model, te["text"].tolist())
    test_metrics = evaluate_probs(te["label"].tolist(), p_test, prefix="test", outdir=args.out)
    print("[DONE] Test metrics:", test_metrics)

    # Demo
    demo = {
        "video_title":"Natural remedy for depression that doctors hide",
        "video_description":"Simple home method.",
        "audio_transcript":"You don't need medication, just do this one trick daily…"
    }
    demo_prompt = (
        "classify mental health misinformation.\n\n"
        f"[TITLE] {demo['video_title']}\n[DESC] {demo['video_description']}\n[TRANSCRIPT] {demo['audio_transcript']}\n"
        f"{PROMPT_SUFFIX}"
    )
    p_demo = float(predict_proba_texts(tokenizer, model, [demo_prompt])[0])
    print("Demo P(misinformation):", round(p_demo, 3))

if __name__ == "__main__":
    main()
