import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

# Additional imports for explainability
from lime.lime_text import LimeTextExplainer
import shap
import numpy as np


def main():
    # 1. Load dataset
    df = pd.read_csv("videos_MHMisinfo_Prepared.csv")

    # 2. Combine text fields into one input
    df["text"] = (
        df["video_title"].fillna("") + " " +
        df["video_description"].fillna("") + " " +
        df["audio_transcript"].fillna("")
    )

    # 3. Define features and labels
    X = df["text"]
    y = df["label"]  # 'reliable' or 'misinformation'

    # 4. Train/test split (stratified to preserve class ratios)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # 5. TF-IDF Vectorization
    vectorizer = TfidfVectorizer(
        stop_words="english",
        max_features=20000,
        ngram_range=(1, 2)  # unigrams + bigrams
    )
    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)

    # 6. Train Logistic Regression with balanced class weights
    clf = LogisticRegression(max_iter=2000, class_weight="balanced")
    clf.fit(X_train_tfidf, y_train)

    # 7. Evaluate model performance
    y_pred = clf.predict(X_test_tfidf)
    print("\nClassification Report:\n")
    print(classification_report(y_test, y_pred))

    # 8. Plot Confusion Matrix
    cm = confusion_matrix(y_test, y_pred, labels=clf.classes_)
    sns.heatmap(
        cm, annot=True, fmt="d",
        xticklabels=clf.classes_, yticklabels=clf.classes_, cmap="Blues"
    )
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.title("Confusion Matrix - TF-IDF + Logistic Regression")
    plt.show()

    # 9. Show top indicative words
    feature_names = vectorizer.get_feature_names_out()
    coefs = clf.coef_[0]
    top_misinfo_idx = coefs.argsort()[-15:][::-1]
    top_reliable_idx = coefs.argsort()[:15]

    print("\nTop words indicating MISINFORMATION:")
    for i in top_misinfo_idx:
        print(f"{feature_names[i]} ({coefs[i]:.3f})")

    print("\nTop words indicating RELIABLE:")
    for i in top_reliable_idx:
        print(f"{feature_names[i]} ({coefs[i]:.3f})")

    # Class names
    class_names = clf.classes_

    # Sample 3 test instances for LIME explanation
    sample_texts = list(X_test[:3])
    explain_with_lime(clf, vectorizer, sample_texts, class_names)

    # SHAP explanation on a subset (e.g., first 100 test instances)
    explain_with_shap(clf, X_test_tfidf[:100], vectorizer)


# LIME explanation function
def explain_with_lime(clf, vectorizer, text_samples, class_names):
    explainer = LimeTextExplainer(class_names=class_names)
    for text in text_samples:
        exp = explainer.explain_instance(text, clf.predict_proba, num_features=10)
        print(f"\nLIME explanation for text: {text[:100]}...")
        exp.show_in_notebook(text=True)  # For Jupyter Notebook
        print("Explanation (feature contribution):")
        for feature, weight in exp.as_list():
            print(f"{feature}: {weight:.4f}")


# SHAP explanation function
def explain_with_shap(clf, X_tfidf, vectorizer):
    explainer = shap.LinearExplainer(clf, X_tfidf, feature_dependence="independent")
    shap_values = explainer.shap_values(X_tfidf)
    feature_names = vectorizer.get_feature_names_out()
    print("\nSHAP summary plot (feature importance across dataset):")
    shap.summary_plot(shap_values, features=X_tfidf, feature_names=feature_names, show=True)


if __name__ == "__main__":
    main()
